import {hasLocale} from 'next-intl';
import {getRequestConfig} from 'next-intl/server';
import { routing } from './routing';

export default getRequestConfig(async ({requestLocale}) => {
    const requested = typeof requestLocale === 'string' ? requestLocale : undefined;
    const locale = hasLocale(routing.locales, requested)
        ? requested
        : routing.defaultLocale;

    const mod = await import(`../messages/${locale}.json`);

    return {
        locale,
        messages: (mod as any).default ?? mod,
        timeZone: 'Europe/Warsaw'
    };
});